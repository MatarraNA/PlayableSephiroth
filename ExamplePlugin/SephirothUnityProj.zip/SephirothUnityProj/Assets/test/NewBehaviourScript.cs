﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
        var myLoadedAssetBundle
            = AssetBundle.LoadFromFile(@"C:/Users/vinny/RoR2 Mods/Assets/test/itempack");
        if (myLoadedAssetBundle == null)
        {
            Debug.Log("Failed to load AssetBundle!");
        }
        Debug.Log(myLoadedAssetBundle.AllAssetNames().ToString());
        var prefab = myLoadedAssetBundle.LoadAsset<GameObject>("oncemore_particle");
        Instantiate(prefab);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
